var { ipcRenderer } = require('electron')
window.local = { ipcRenderer }
