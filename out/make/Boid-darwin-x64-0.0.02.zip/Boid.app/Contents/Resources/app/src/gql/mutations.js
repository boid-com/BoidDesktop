function gql(strings) {
  return strings[0]
}

var mutations = {}

module.exports = mutations
