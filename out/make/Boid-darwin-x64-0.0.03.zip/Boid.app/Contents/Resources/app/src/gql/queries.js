function gql(strings) {
  return strings[0]
}
var queries = {}

module.exports = queries
